import { Component, OnInit } from '@angular/core';
import { SocketService } from './socket.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ChatGroupComponent } from './chat-group/chat-group.component';
import {PageEvent , MatTableDataSource, MatSort, MatPaginator } from '@angular/material';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'client';
  dubli
  user: string;
  room: string;
  message: string;
  messageText: string;
  messages: string[] = [];
  messageArray: Array<{ user: String, message: String }> = []
  roomArray: Array<{ user: String, room: String }> = []
  messageReceiveArray: Array<{ message: String }> = []

  data: any = [];
  dataSource = new MatTableDataSource<any>([]);
  constructor(private webSocket: SocketService,private dialog: MatDialog,) {


  }

  ngOnInit() {

    this.webSocket.getMessages('new message').subscribe(data => {
      console.log(data)
      this.messageArray.push(data);

    })

    this.webSocket.newUserJoin('test join').subscribe(data => {
      console.log(data);
      this.dubli=data.room
      this.roomArray.push(data);
    })


  }

  sendMessage() {
    this.webSocket.sendMessage({ user: this.user, room: this.room, message: this.messageText });
    this.messageText = '';
  }


  join() {
    this.webSocket.joinRoom({ user: this.user, room: this.room })
  }

  open(data) {
    const dialogCofig = new MatDialogConfig();
    dialogCofig.disableClose = true;
  
    this.dialog.open(ChatGroupComponent, dialogCofig).afterClosed()
    .subscribe(response => {
      this.data = response;
      this.dataSource = new MatTableDataSource(response as any);
  
     
  
    });
  }


}
