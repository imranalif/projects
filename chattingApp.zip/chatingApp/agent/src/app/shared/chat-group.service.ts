import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ChatGroupService {
  private url = 'http://localhost:3000/chat_group';
  constructor(private http: HttpClient) { }

  addGroup(data){
    console.log(data)
    return this.http.post(this.url + '/addGroup', data);
  }
}
