import { TestBed } from '@angular/core/testing';

import { ChatGroupService } from './chat-group.service';

describe('ChatGroupService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ChatGroupService = TestBed.get(ChatGroupService);
    expect(service).toBeTruthy();
  });
});
