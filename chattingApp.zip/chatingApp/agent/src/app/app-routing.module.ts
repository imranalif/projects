import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChatGroupComponent } from './chat-group/chat-group.component';


const routes: Routes = [{
  path: 'group',
  component: ChatGroupComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
