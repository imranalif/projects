import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatDialog } from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { SocketService } from '../socket.service';
import { ChatGroupService } from '../shared/chat-group.service';

@Component({
  selector: 'app-chat-group',
  templateUrl: './chat-group.component.html',
  styleUrls: ['./chat-group.component.css']
})
export class ChatGroupComponent implements OnInit {
  myform: FormGroup;
  states = [{id: 1, value: 'Active' }, {id: 0, value: 'Inactive' }];
  constructor(private chatGroup: ChatGroupService,private fb: FormBuilder,private dialogRef: MatDialogRef<ChatGroupComponent>) { }

  ngOnInit() {
    this.myform = this.fb.group({
      name: [""],
      description: [""],
      icon: [""],
      status: [""], 
    });
  }

  addGroup(){
this.chatGroup.addGroup(this.myform.value).subscribe()
console.log(this.myform.value)
this.close()
  }

  close(): void {
    this.dialogRef.close();
  }

}
