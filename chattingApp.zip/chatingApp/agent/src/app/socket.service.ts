import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as io from 'socket.io-client'
import { Observable, Subscriber, observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class SocketService {
  socket: any;
  private url = 'http://localhost:3000/';
  constructor(private http: HttpClient) {
    this.socket = io(this.url)
  }

  

  newUserJoin(eventName: string) {
    return new Observable<{ user: String, room: String }>((subscriber) => {
      this.socket.on(eventName, (data) => {
        subscriber.next(data)
      })
    })
  }


  joinRoom(data) {
    this.socket.emit('join', data);
  }


  public sendMessage(data) {
    this.socket.emit('message', data);
  }

  getMessages(eventName: string) {
    return new Observable<{ user: string, message: string }>((subscriber) => {
      this.socket.on(eventName, (data) => {
        subscriber.next(data)
      })
    })
  }



}
