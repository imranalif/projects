const express = require("express");

const router = express.Router();

const Group = require("../model/chat_group.js");


router.post("/addGroup", (req, res) => {
    
    console.log(req.body);
    Group.create({
      name:req.body.name,
      description:req.body.description,
      icon:req.body.icon,
      createdBy:1,
      updatedBy:'',
      updatedTime:'',
    
      status:req.body.status
    })
      .then(data => {
        console.log(data);
        res.send(data);
      })
      .catch(err => {
        res.json("error:" + err);
      });
  });




module.exports = router;