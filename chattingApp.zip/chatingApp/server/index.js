const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const http = require("http")
const socketio = require("socket.io")
const Sequelize = require("sequelize");

const Mess = require("./model/message");
const chat_group = require("./routes/chat_group.js");
const PORT = 3000;
const app = express();
app.use(cors());

const db = require("./config/db.js");



db.authenticate()
  .then(() => console.log("database connected"))
  .catch(err => console.log(err));
  
  app.use(bodyParser.json());
  
app.use("/chat_group",chat_group)

const server = http.Server(app);
const io = socketio(server);

io.on('connection', (socket) => {
  console.log('a user is connected');

  socket.on('join', (data) => {
    socket.join(data.room);
    console.log(data.user + ' joined to room ' + data.room);
    //io.to(data.room).emit('test join', { user: data.user, message: 'has joined this room.' })
    io.to(data.room).emit('test join', { user: data.user, room: data.room })
  })



  socket.on('message', (data) => {
    io.in(data.room).emit('new message', { user: data.user, message: data.message })
    Mess.create({ user: data.user, message: data.message })
      .then(data => {
        console.log(data);
        //res.send(data);
      })
      .catch(err => {
        //res.json("error:" + err);
      });
  });
})

server.listen(PORT, function () {
  console.log("server running on port: " + PORT);
});