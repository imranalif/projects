const Sequelize = require("sequelize");
const db = require("../config/db.js");

const mess = db.define("messages", {
  user: { type: Sequelize.STRING },
  message: { type: Sequelize.STRING },
  
});

module.exports = mess;