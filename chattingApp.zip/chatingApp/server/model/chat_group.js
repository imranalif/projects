const Sequelize = require("sequelize");
const db = require("../config/db.js");

const Group = db.define("chat_groups", {
  name: { type: Sequelize.STRING },
  description: { type: Sequelize.STRING },
  icon: { type: Sequelize.STRING },
  createdBy:{ type: Sequelize.STRING },
   createdTime:{ type: Sequelize.STRING },
  updatedBy:{ type: Sequelize.STRING },
  updatedTime:{ type: Sequelize.STRING },
  status: { type: Sequelize.STRING },
  
});

module.exports = Group;